# Handoff: Evans Marketing — Marketing Website (4 pages)

## Overview
A four-page marketing site for **Evans Marketing**, the independent growth-strategy and performance-marketing consultancy of **Ariel Evans** (Vancouver, B.C.; 15+ years in digital, 40+ brands, SMB through Fortune 500). Pages: **Home, Services, About, Contact**. The visual direction is a print/fashion-editorial magazine: warm neutral palette, hairline rules, numbered running heads, an ultra-heavy grotesque for display, a Didone serif for the wordmark and pull quotes, and one saturated red accent.

## About the Design Files
The files in `design/` are **design references authored in HTML** — prototypes that show intended look, content and behavior. They are **not production code to copy**. Recreate them in the target codebase's existing environment (React/Next, Vue, Astro, etc.) using its established patterns, routing, component library and CSS approach. If no codebase exists yet, pick the most appropriate framework (Next.js + a CSS approach of your choice is a safe default for a marketing site) and implement there.

Two implementation notes about the references:
- They are authored as "Design Components": each file is an HTML document whose body contains an `<x-dc>` template plus a small logic class, executed by `design/assets/support.js`. **Ignore that runtime.** Read the markup and inline styles as the spec; the only real behavior is the Services accordion (see Interactions).
- All styling is **inline** by design-tool constraint. In production, extract it into your normal styling layer (tokens/utility classes/components) — do not ship inline styles.

## Fidelity
**High-fidelity.** Colors, type sizes, tracking, spacing and copy are final and should be matched closely. Copy is client-approved and should be reproduced verbatim unless the client says otherwise.

---

## Global shell

### Page frame
- Page background: `#121110`. Content sections are stacked in a vertical flex column with **1px gaps**, so the dark page shows through as hairline rules between full-bleed sections. No rounded corners anywhere, no drop shadows.
- Section horizontal padding: `34px` (large sections), `40px` (centered quote/slab sections). Vertical padding varies per section, noted below.
- Max width: none — sections are full-bleed; interior text blocks are constrained with `max-width`.

### Header (sticky, identical on all pages)
- `position: sticky; top: 0; z-index: 60`, background `#FAF5EA`, `border-bottom: 1px solid #121110`, padding `20px 34px`.
- 3-column grid `1fr auto 1fr`, `gap: 20px`, vertically centered.
- Left: nav links — Home / Services / About / Contact. `10px`, weight 500, `letter-spacing: 0.22em`, uppercase, `gap: 24px`. Inactive `#121110` with `border-bottom: 1px solid transparent`; **active page** `#B4322A` with `border-bottom: 1px solid #B4322A`, `padding-bottom: 3px`.
- Center: wordmark "EVANS MARKETING" — Bodoni Moda 500, `clamp(19px, 2.1vw, 28px)`, `letter-spacing: 0.22em`, uppercase, `line-height: 1`, `#121110`, `white-space: nowrap`. Links to Home.
- Right: secondary link "Book a session" → Contact. `10px`, weight 500, `0.22em`, uppercase, `#121110`, `padding-bottom: 5px`, `border-bottom: 1px solid #121110`, `white-space: nowrap`. Hover: text and border `#B4322A`. (Deliberately a hairline link, not a button.)

### Footer (identical on all pages)
- Background `#121110`, `border-top: 1px solid rgba(250,245,234,0.2)`, padding `26px 34px`, `display:flex; justify-content:space-between; align-items:center; gap:20px; flex-wrap:wrap`.
- Three items, `10px`, weight 500, `0.22em`, uppercase, color `#C9BCAE`:
  1. "Evans Marketing" — Bodoni Moda `19px`, `letter-spacing: 0.2em`, `#FAF5EA`
  2. "Performance is the strategy"
  3. "© 2026 · All rights reserved"

### Grain overlay
Most light sections carry a subtle film-grain layer: an absolutely-positioned `inset: 0` div, `pointer-events: none`, `mix-blend-mode: multiply`, `opacity: 0.12–0.16` (0.2 on the sand quote band), filled with an inline SVG `feTurbulence` fractal noise (`baseFrequency` 0.82–0.95, `numOctaves: 4`). In production use a small tiling PNG/WebP noise texture instead (a 160×160 grey-noise tile at the same opacity/blend is equivalent — `design/assets/` ships one as `grain.png` in the project if needed). Keep it subtle; it should never be legible as a pattern.

---

## Screens / Views

### 1. Home (`design/Home.dc.html`)
Purpose: establish the positioning, prove credibility, route to Services and Contact.

Sections in order:

**1a. Hero — photo-in-type (background `#121110`, color `#FAF5EA`, padding `56px 34px 44px`)**
- Top meta row: `display:flex; justify-content:space-between`, `10px`, weight 600, `0.26em`, uppercase. Items: "Vancouver, B.C." (`#C9BCAE`), "Growth strategy & performance marketing" (`#B4322A`), "Fifteen years in market" (`#C9BCAE`).
- Headline: three lines — **GROWTH / THROUGH / INSIGHT** — Archivo Black, `clamp(58px, 15.6vw, 250px)`, `line-height: 0.76`, `letter-spacing: -0.045em`, uppercase, centered. The letterforms are **filled with a photograph**: `color: transparent` + `background-clip: text` over a two-layer background — `linear-gradient(rgba(18,17,16,0.4), rgba(18,17,16,0.4))` above `url(assets/hero-type-fill.png)`, both `background-size: 100% 100%`, centered. Also `-webkit-text-stroke: 0.75px rgba(18,17,16,0.7)` as a visibility fallback.
  - **Implementation note:** `hero-type-fill.png` is a pre-processed crop of Ariel's portrait (hair/face band), converted to greyscale and pushed dark with a gamma curve (mean luma ≈ 88) specifically so the type reads as near-black. Do not substitute a raw photo; a light photo makes the headline vanish. If the image is replaced, re-darken it the same way and keep the dark overlay layer.
- Below, 2-column grid `1.2fr 0.8fr`, `gap: 44px`, `align-items: end`, `padding-top: 56px`:
  - Left: intro paragraph, `14px`, `line-height: 1.7`, `#33291F`… **on the dark hero this should be a light tone** — in the reference it is `#33291F`; use `#DCD1C2`/`#EFE7DA` in production for contrast (flagged in Known Issues).
  - Right: stats row (`gap: 44px`) — "15+" and "40+" in Archivo Black `32px`, `line-height: 1`, with labels "Years in digital" / "Brands partnered" (`10px`, 500, `0.22em`, uppercase, `#C9BCAE`, `padding-top: 8px`); then the primary CTA button.

**1b. Pull quote band (background `#DED3C4`, `min-height: 620px`, centered, padding `80px 40px`)**
- Full-bleed blurred portrait: `assets/editorial-portrait.png`, `object-fit: cover`, `object-position: 50% 6%`, `filter: blur(10px) saturate(0.9)`, `transform: scale(1.18)`; over it a `rgba(240,232,220,0.44)` wash, then the grain layer.
- Quote (max-width `860px`, centered): "Because growth starts when the numbers and the customer finally tell the same story." — Bodoni Moda **italic** 500, `clamp(26px, 3.6vw, 58px)`, `line-height: 1.24`, `letter-spacing: -0.01em`, color `#B4322A`, `text-wrap: balance`.
- Attribution: "Ariel Evans" — `10px`, 500, `0.26em`, uppercase, `#33291F`, `padding-top: 26px`.

**1c. Customized Solutions (2-column section, background `#FAF5EA`, grid `1.05fr 0.95fr`)**
- Left column, padding `76px 44px 68px 34px`:
  - Running head: flex row, `padding-bottom: 14px`, `border-bottom: 1px solid rgba(18,17,16,0.28)`, `10px`, 600, `0.28em`, uppercase — "We provide" (`#B4322A`) / folio "01" (`#8E8175`).
  - H2 "Customized solutions" — Archivo Black, `clamp(34px, 5.6vw, 92px)`, `line-height: 0.84`, `letter-spacing: -0.03em`, uppercase.
  - Body: **CSS multi-column** — `columns: 2; column-gap: 34px; column-rule: 1px solid rgba(18,17,16,0.2)`, `max-width: 660px`, `padding-top: 32px`. Three paragraphs at `13.5px`/`1.7`, `#33291F`. The first paragraph opens with a **drop cap**: floated span, Bodoni Moda 500, `54px`, `line-height: 0.76`, `padding: 5px 8px 0 0`, color `#B4322A`.
  - CTA button "Explore our approach" → Services (`margin-top: 38px`).
- Right column (background `#3B2418`, padding `44px 34px`, flex column, `justify-content: space-between`, `gap: 28px`):
  - Label row: "The ecosystem" (`#C4A47C`) / "Every touchpoint, one funnel" (`#C9BCAE`), `10px`, 600, `0.26em`, uppercase.
  - `assets/ecosystem-brand.png`, `width: 100%; height: auto` — the funnel→CRM diagram, **recolored** from its original black/red into chocolate `#3B2418` field, ivory `#FAF5EA` cards, sand `#C4A47C` accents. Use this recolored file, never the original.
  - Caption: Bodoni Moda italic `15px`/`1.5`, `#EFE7DA`.

**1d. Brands marquee (background `#FAF5EA`, padding `58px 0 48px`)**
- H2 "Brands we've partnered with" — same section-head style as above, in a flex row with `padding: 0 34px 36px`.
- Two infinite marquee rows inside a block with `border-top`/`border-bottom: 1px solid rgba(18,17,16,0.2)`, `padding: 30px 0`, `gap: 18px`:
  - Row 1 (`animation: marquee 52s linear infinite`), color `#33291F`: Rolex · Chopard · Aritzia · Coach · Nordstrom · Ted Baker · Tudor · Mazda · Accor · Wyndham Hotels · Whistler Blackcomb · Tourism Vancouver
  - Row 2 (`58–64s`, `reverse`), color `#8E8175`: Anthem Properties · Concert Properties · Rennie · California Closets · Benjamin Moore · Seaspan · Grant Thornton · UBC · Nando's · Project Skin MD · Alpine Credits · Verve Living
  - Each name: Archivo Black `22px`, `letter-spacing: -0.01em`, uppercase, `padding: 0 40px`. Keyframes: `from { translateX(0) } to { translateX(-50%) }`; the track contains the list **twice** and is `width: max-content`.
  - **Production:** these are text wordmarks standing in for real client logos. If the client supplies logo files, swap to images at a common optical height and keep the same marquee mechanics. Also confirm usage rights — several are agency-of-record accounts from Ariel's Lodestar/Glacier tenure.
- Category line under the rows: "Luxury · Retail · Property · Hospitality · Professional services", `10px`, 500, `0.22em`, uppercase, `#8E8175`, `padding: 24px 34px 0`.

**1e. "Excellence" slab (padding `132px 40px`, background `#EFE7DA`)**
- Full-bleed `assets/paper-type-brand.png` (`object-fit: cover`) — a paper/letterform collage, **recolored** to remove its blush-pink patches (all rose pixels remapped onto the beige→sand ramp). Over it a `rgba(247,241,233,0.46)` cream wash.
- Centered, `max-width: 1080px`: label "The standard" (`10px`, 600, `0.28em`, uppercase, `#B4322A`), then "Excellence in your work opens the door to even greater opportunities." — Bodoni Moda italic 500, `clamp(28px, 3.8vw, 62px)`, `line-height: 1.2`, `text-wrap: balance`.

**1f. Closing CTA band (background `#FAF5EA`, `border-top: 1px solid #121110`, padding `56px 34px`)**
- `display: grid; grid-template-columns: minmax(0, 1fr) auto; align-items: center; gap: 40px`.
- Left: "Curious about how we can elevate your business?" — Bodoni Moda italic 500, `clamp(22px, 2.6vw, 40px)`, `line-height: 1.22`, `max-width: 520px`.
- Right: primary CTA button → Contact.

### 2. Services (`design/Services.dc.html`)
Purpose: let a prospect scan twelve offers and read only what's relevant.

**2a. Masthead (background `#121110`, color `#FAF5EA`, padding `64px 34px 56px`)**
- Running head: "Our solutions for your growth" (`#C4A47C`) / "Twelve services" (`#C9BCAE`), `10px`, 600, `0.28em`, uppercase, `padding-bottom: 16px`, `border-bottom: 1px solid rgba(250,245,234,0.24)`.
- H1 "SERVICES" — Archivo Black, `clamp(48px, 11.4vw, 200px)`, `line-height: 0.8`, `letter-spacing: -0.045em`, uppercase, `margin-top: 38px`.
- Grid `1.15fr 0.85fr`, `gap: 44px`, `align-items: end`, `padding-top: 40px`: standfirst in Bodoni Moda italic, `clamp(19px, 1.9vw, 27px)`, `line-height: 1.4`, `#F2EADF`, `max-width: 620px`; right side three engagement tags — "Project", "Retained", "Embedded in your team" (`10px`, 600, `0.22em`, uppercase, `#C9BCAE`, `gap: 28px`).

**2b. Accordion index (background `#FAF5EA`, padding `12px 34px 56px`)**
- Index header row: "The index" (`#B4322A`) / "Select a service to read more" (`#8E8175`), `10px`, 600, `0.28em`, uppercase, `padding: 34px 0 18px`.
- Twelve rows. Each row: wrapper with `border-top: 1px solid rgba(18,17,16,0.28)` (last row also `border-bottom`), `padding: 0 22px`, and a background that is `#EFE7DA` when open, `transparent` when closed.
  - Trigger: a `<button>` — `display: grid; grid-template-columns: 52px 1fr auto; gap: 22px; align-items: center; width: 100%; padding: 26px 0; border: none; background: transparent; color: #121110; text-align: left; cursor: pointer`; hover color `#B4322A`.
    - Index number ("01"…"12"): `10px`, 600, `0.16em`, `#B4322A`.
    - Title: Archivo Black, `clamp(20px, 2.4vw, 34px)`, `line-height: 1`, `letter-spacing: -0.025em`, uppercase, `color: inherit` (so it takes the button's ink and the red hover — an earlier bug had it inheriting the UA button color and rendering near-white).
    - Marker: Bodoni Moda `26px`, `#8E8175`, showing `+` when closed and `–` when open.
  - Panel: `display: grid | none` (driven by state — see Interactions), `grid-template-columns: 52px minmax(0, 640px)`, `gap: 22px`, `padding: 0 0 30px`; an empty spacer cell keeps copy aligned with the titles. Body copy `15px`/`1.75`, `#241C14`.
- Services and copy, in order: **01 Growth Strategy · 02 Search Engine Marketing · 03 E-commerce Strategy · 04 Search Engine Optimization · 05 B2B Lead Generation · 06 Programmatic Advertising · 07 Social Performance · 08 Content Marketing · 09 Brand Performance · 10 Email Marketing · 11 Recruitment Marketing · 12 Creative Design & Branding.** Exact paragraph copy is in the HTML — reproduce verbatim. Row 06 additionally lists four channel tags below its paragraph: Display / Audio / DOOH / Connected TV (`10px`, 600, `0.2em`, uppercase, `#8E8175`, `gap: 26px`).

**2c. "How we work" process (background `#DED3C4`, padding `70px 34px 62px`)**
- Header grid `1.1fr 0.9fr`, `gap: 56px`, `align-items: start`, `padding-bottom: 48px`: left — running head "The process" / "Five steps" on a `rgba(18,17,16,0.4)` rule, then H2 "How we work" (Archivo Black, `clamp(32px, 5.2vw, 84px)`, `line-height: 0.84`, `letter-spacing: -0.035em`, uppercase); right — intro paragraph `13.5px`/`1.7` (`max-width: 440px`) plus the primary CTA button.
- Five equal columns (`repeat(5, 1fr)`, `gap: 24px`), each: `padding-top: 20px`, `border-top: 1px solid rgba(18,17,16,0.4)`; numeral "01"–"05" in Archivo Black `34px`; title in Archivo Black `15px`, `letter-spacing: -0.015em`, uppercase, `min-height: 2.4em` (keeps titles baseline-aligned across the row); body `13px`/`1.7`, `#33291F`. Steps: Strategy Session · Gathering Insights · Crafting Your Strategy · Planning for Success · Implementation & Growth.

**2d. Closing CTA band** — same as 1f, quote reads "Growth isn't luck — it's engineered, step by step."

### 3. About (`design/About.dc.html`)
**3a. Masthead** — same construction as 2a: running head "The founder" / folio "04", H1 "ABOUT" (`clamp(44px, 9.4vw, 164px)`), standfirst "Fifteen years at the intersection of data, creative and strategy — helping founders and marketing teams turn spend into growth that compounds." (Bodoni italic, `#F2EADF`).

**3b. Founder spread** — 2-column grid `1fr 1fr`, `gap: 1px`:
- Left: `assets/ariel.jpg`, `min-height: 660px`, `object-fit: cover`, `object-position: 50% 18%`, `filter: grayscale(1) contrast(1.1)`, background `#DED3C4`, plus grain. Anchored caption bar at the bottom: background `#121110`, padding `18px 24px`, flex row `justify-content: space-between`, `align-items: baseline` — "Ariel Evans" (Bodoni Moda `21px`, `letter-spacing: 0.08em`, uppercase, `#FAF5EA`) and "Founder" (`10px`, 500, `0.24em`, uppercase, `#C4A47C`).
- Right (background `#FAF5EA`, padding `76px 44px 60px`): running head "About" / folio "04"; H2 "Ariel Evans" — **Bodoni Moda 500**, `clamp(34px, 4.2vw, 68px)`, `line-height: 1`, `letter-spacing: -0.015em` (the one place a name gets the serif at display size); a row of three tracked-caps words "Strategist / Operator / Analyst" (`10px`, 500, `0.24em`, uppercase, `#8E8175`, `gap: 24px`); two bio paragraphs `14.5px`/`1.6`, `#33291F`; then a stats strip (`grid-template-columns: repeat(3, 1fr)`, `margin-top: 34px`, `padding-top: 26px`, `border-top: 1px solid rgba(18,17,16,0.2)`) — "15+ / Years in digital", "40+ / Brands partnered" (Archivo Black `30px` + `10px` caps labels), and a third cell reading "SMB to Fortune 500" (Archivo `13px`, 600, `0.1em`, uppercase) labelled "Client range".

**3c. Exceptional Strategies (background `#DED3C4`, padding `84px 34px 76px`)**
- Grid `1.1fr 0.9fr`, `gap: 56px`, `align-items: start`.
- Left column (`gap: 34px`): H2 "Exceptional strategies that truly perform" (Archivo Black section-head scale) and `assets/studio-flatlay.png` at `width: 100%; height: 340px; object-fit: cover`.
- Right column: two paragraphs `13.5px`/`1.7`; then an engagement block — `margin-top: 14px`, `padding-top: 22px`, `border-top: 1px solid rgba(18,17,16,0.28)`, label "How we work together" (`10px`, 600, `0.28em`, uppercase) and three items "Project engagement / Retained partnership / Embedded in your team" (Archivo `12.5px`, 600, `0.12em`, uppercase, `gap: 10px`).

**3d. Pull quote band** (same as 1b) and **3e. Closing CTA band** (same as 1f, quote "Let's find the next increment of growth in your numbers.").

### 4. Contact (`design/Contact.dc.html`)
**4a. Contact section (background `#3B2418`, color `#FAF5EA`, padding `80px 34px 68px`)** — grain layer uses `mix-blend-mode: screen`, `opacity: 0.26`.
- Grid `1fr 1fr`, `gap: 64px`.
- Left: running head "Get in touch" (`#C4A47C`) / folio "05" (`#C9BCAE`) on a `rgba(250,245,234,0.3)` rule; H2 "Curious about how we can **elevate your business?**" — Archivo Black, `clamp(30px, 4.2vw, 70px)`, `line-height: 0.86`, `letter-spacing: -0.03em`, uppercase, with the second clause in `#C4A47C`; supporting paragraph `13.5px`/`1.7`, `#EFE7DA`, `max-width: 420px`; then a details block (`margin-top: 36px`, `padding-top: 26px`, `border-top: 1px solid rgba(250,245,234,0.28)`, `gap: 14px`) — email and phone as Archivo 500 `17px` links (`#FAF5EA`, hover `#C4A47C`) plus "Vancouver, British Columbia" (`10px`, 500, `0.24em`, uppercase, `#C9BCAE`).
- Right: the form — `display: grid; grid-template-columns: repeat(2, 1fr); gap: 26px; align-content: start`. Fields: First name, Last name, Email, Phone (each half-width), Company and "What can we help with?" (each `grid-column: span 2`; the last is a `textarea rows=3 maxlength=600 resize:none` with placeholder "Have a question for us? Ask away."). Every field: label above (`10px`, 500, `0.22em`, uppercase, `#C9BCAE`, `gap: 8px`), input with `border: none; border-bottom: 1px solid rgba(250,245,234,0.55); background: transparent; font-size: 15px; color: #FAF5EA; outline: none; padding: 12px 0`. Submit is the light CTA button (cream on chocolate) spanning both columns with `padding-top: 10px`.
- **Contact details are placeholders pending client confirmation:** `hello@evansmarketing.ca`, `+1 604 362 5794`. The phone is Ariel's Lodestar line; the email domain was invented for the independent brand. Confirm both before launch.

**4b. Brands marquee** — same component as 1d.

---

## Interactions & Behavior
- **Nav** — plain page-to-page links; the current page is red with a red underline. No mobile menu is designed yet (see Known Issues).
- **Services accordion** — single-open. One state value (`open`, an index) starts at `0` (Growth Strategy open on load). Clicking a row's button opens it and closes the previous one; clicking the open row closes it (`open = -1`). Per row the state drives three things: panel `display` (`grid` / `none`), row background (`#EFE7DA` / `transparent`), and the marker glyph (`–` / `+`).
  - **Do not** implement "closed" with the HTML `hidden` attribute on an element that also carries an inline `display` — `[hidden] { display: none }` loses to the inline value and nothing collapses. Toggle `display` (or use a proper `<details>`/disclosure component in your framework) and give the trigger `aria-expanded` + `aria-controls`, which the reference lacks.
  - Optional enhancement, not in the reference: animate the panel open with a height/opacity transition (~200ms ease) and respect `prefers-reduced-motion`.
- **Brand marquee** — CSS keyframe translation, infinite linear, one row forward (52s) and one reverse (58–64s). Duplicate the list so the loop is seamless. Pause on hover and under `prefers-reduced-motion: reduce` in production.
- **Buttons/links hover** — primary buttons swap background to `#B4322A` (dark buttons) or `#C4A47C` (light buttons on dark grounds) with the text staying legible; hairline links swap text and border to the accent. No transitions are specified; a `150ms ease` on color/background is welcome.
- **Contact form** — the reference only prevents default and swaps the submit label to "Thank you — we'll be in touch". Real implementation needs an endpoint (or the client's marketing-automation form), field validation (all fields required except the message; email/phone format), the 600-character cap on the message, inline error styling in `#B4322A`, a success state, and spam protection.
- **Responsive** — **not designed.** Every multi-column grid is fixed (`1fr 1fr`, `repeat(5, 1fr)`, `columns: 2`) and type uses `clamp()` only. Tablet/mobile breakpoints must be authored: collapse two-column sections to one, the five-step process to a 1–2 column stack, the CSS multi-column body to a single column, the hero stats to a row that wraps, and the header nav to a menu. Keep the photo-in-type headline legible at small sizes (reduce to two lines if needed).

## State Management
Minimal — this is a marketing site.
- `Services`: `open: number` (index of the expanded row; `-1` = all closed). No fetching.
- `Contact`: form field values, `submitted: boolean`, plus validation/error state once wired to a real endpoint.
- No global state, no auth, no data fetching anywhere in the design.

## Design Tokens

### Color
| Token | Hex | Use |
| --- | --- | --- |
| Ink / page | `#121110` | page frame, hero + footer grounds, hairline borders, primary button fill |
| Chocolate | `#3B2418` | ecosystem panel, contact section ground |
| Cream | `#FAF5EA` | primary light ground, text on dark grounds |
| Sand-grey | `#DED3C4` | secondary light ground (quote band, process, Exceptional Strategies) |
| Warm sand | `#EFE7DA` | open accordion row, "Excellence" slab base, light copy on dark |
| Sand accent | `#C4A47C` | accent on dark grounds, light-button hover |
| Red accent | `#B4322A` | the only saturated color: labels, active nav, drop cap, quote color, hover states |
| Body brown | `#33291F` | body copy on light grounds |
| Deep brown | `#241C14` | accordion panel copy (slightly darker for the tinted row) |
| Label grey | `#8E8175` | small caps labels/folios on light grounds |
| Light grey | `#C9BCAE` | small caps labels on dark grounds |
| Near-cream | `#F2EADF` | italic standfirsts on dark grounds |
Overlays used: `rgba(18,17,16,0.2 / 0.28 / 0.4)` hairlines on light; `rgba(250,245,234,0.2 / 0.24 / 0.28 / 0.3 / 0.55)` hairlines on dark; `rgba(240,232,220,0.44)` and `rgba(247,241,233,0.46)` image washes; `rgba(18,17,16,0.4)` inside the clipped headline stack.

### Typography
- **Archivo Black** (Google) — display: hero, section heads, service titles, process numerals/titles, stat numerals. Always uppercase, negative tracking `-0.015em` to `-0.045em`, `line-height` 0.76–1.
- **Bodoni Moda** (Google, optical-size axis, weights 400/500/600 + italics) — wordmark, pull quotes (italic), the "Ariel Evans" heading, drop cap, accordion +/– markers, captions (italic). Large sizes only; never body.
- **Archivo** (Google, 400/500/600) — everything structural: body 400, labels/nav/tags 500–600 with `0.1em–0.3em` tracking and uppercase.
- Scale: display `clamp(32px–58px, 5–15.6vw, 84–250px)`; section heads `clamp(30px, 3.6–5.6vw, 56–92px)`; service titles `clamp(20px, 2.4vw, 34px)`; pull quotes `clamp(22–28px, 2.6–3.8vw, 40–62px)`; standfirst `clamp(19px, 1.9vw, 27px)`; body 13–15px at `line-height` 1.6–1.75; labels 10–12.5px.
- Load: `Bodoni+Moda:ital,opsz,wght@0,6..96,400;0,6..96,500;0,6..96,600;1,6..96,400;1,6..96,500;1,6..96,600` + `Archivo:wght@400;500;600` + `Archivo+Black`. Self-host or `next/font` in production.

### Spacing / shape
- Section padding: `56–132px` vertical, `34–40px` horizontal. Column gaps `24px / 34px / 44px / 56px / 64px`. Hairline gutters between sections: `1px`.
- **Border radius: 0 everywhere. No shadows.** Depth comes from hairlines and ground changes only.
- Buttons: `padding: 20px 34px`, `12.5px`, weight 600, `letter-spacing: 0.2em`, uppercase, `white-space: nowrap`.

## Assets
All in `design/assets/`. Several are **derived files** — use the derived version, not the source.
| File | What it is | Notes |
| --- | --- | --- |
| `ariel.jpg` | Founder portrait (client-supplied) | Used greyscaled on About |
| `hero-type-fill.png` | Darkened greyscale crop of `ariel.jpg` | Purpose-built fill for the photo-in-type headline; mean luma ≈ 88 |
| `editorial-portrait.png` | Editorial fashion portrait (AI-generated placeholder) | Blurred background of the quote band — **replace with a real Ariel shoot** |
| `studio-flatlay.png` | Studio desk flatlay (AI-generated placeholder) | About page — replaceable |
| `paper-type-brand.png` | Paper/letterform collage, recolored | Pink patches remapped to beige/sand; original had blush the client rejected |
| `ecosystem-brand.png` | Funnel→CRM diagram, recolored | Chocolate/ivory/sand version of a black-and-red source |
| `arch-still.png` | Beige arch still-life | Not used in the current four pages; kept as an alternate |
| `support.js` | Design-tool runtime | **Not part of the design** — needed only to open the reference HTML files locally |
Fonts come from Google Fonts. No icon set is used anywhere — the only glyphs are `+`, `–`, and `·`.

## Files
- `design/Home.dc.html` — Home
- `design/Services.dc.html` — Services (accordion + process)
- `design/About.dc.html` — About
- `design/Contact.dc.html` — Contact
- `design/assets/*` — images + the runtime needed to view the references

To view a reference locally, serve the `design/` folder over HTTP (the pages load `./support.js`, which they expect beside them — copy `assets/support.js` up one level, or just read the markup).

## Known issues / decisions to make before build
1. **Business identity** — the client never confirmed a legal/agency name; the site is branded "Evans Marketing" throughout.
2. **Contact details** — `hello@evansmarketing.ca` is invented; the phone is Ariel's Lodestar number. If she remains under Lodestar, the positioning copy and the email need revisiting.
3. **Client logo list** — text wordmarks, and the accounts come from Ariel's agency tenure. Confirm attribution/rights, then swap in real logos.
4. **Hero intro paragraph color** — the reference leaves it at `#33291F` on the dark hero; use a light tone.
5. **Responsive + accessibility** — no breakpoints designed; accordion lacks `aria-expanded`/`aria-controls`; marquee and blur effects need `prefers-reduced-motion` handling; verify 10px tracked-caps labels against your contrast bar (they pass on dark after the `#C9BCAE` change, and are borderline at `#8E8175` on cream — consider `#6B5F52` for light grounds).
6. **Placeholder photography** — two AI-generated images stand in for a real shoot.
7. **Grain** — implemented as an inline SVG filter; swap to a tiling texture for performance.
