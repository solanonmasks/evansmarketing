# Animated Hero — implementation spec

Drop-in replacement for the Home hero. `hero.html` in this folder is a **runnable, dependency-free reference** (plain CSS + ~20 lines of vanilla JS, no framework, no build). Open it in a browser to see the finished behavior, then port it into the site.

## What it does

Four layered effects, in order of appearance:

1. **Meta line rise** — the top row ("Vancouver, B.C." / "Growth strategy & performance marketing" / "Fifteen years in market") rises 14px and fades in. `metaRise`, 0.9s, `cubic-bezier(.16,1,.3,1)`, 0.15s delay.
2. **Type develops** — the headline (GROWTH / THROUGH / INSIGHT) is revealed top-to-bottom by animating `clip-path: inset(0 0 100% 0) → inset(0)` while opacity goes 0.15 → 1. `typeDevelop`, 1.25s, same easing. Reads like a photograph coming up in a tray.
3. **Red scan line** — a 2px `#B4322A` bar with a soft glow (`box-shadow: 0 0 26px 6px rgba(180,50,42,.35)`) sweeps from `top: 0%` to `top: 100%` across the headline block, bleeding 34px past both edges so it looks like it crosses the page. `scanSweep`, 1.35s, `cubic-bezier(.65,0,.35,1)`, fades in at 6% and out at 88%. It rides just ahead of the develop wipe.
4. **Living fill + cursor parallax** — the headline's letterforms are filled with a photograph via `background-clip: text`, and that fill never stops moving: `fillDrift` pans and zooms it (150% → 178% → 158%) over **26s**, `ease-in-out`, `infinite alternate`, starting after a 1.3s delay so it begins once the type has developed. Independently, JS translates the whole headline slab a few px toward the cursor and lifts/fades it on scroll.

## The photo-in-type headline

```css
color: transparent;
-webkit-text-stroke: .75px rgba(18,17,16,.7);   /* fallback: type never fully vanishes */
background-image:
  linear-gradient(rgba(18,17,16,.4), rgba(18,17,16,.4)),   /* layer 1: darkening wash */
  url("assets/hero-type-fabric.png");                       /* layer 2: the photo */
background-size: 100% 100%, 150% auto;
background-position: center, 30% 46%;
-webkit-background-clip: text;
        background-clip: text;
```

Non-obvious rules learned the hard way:

- **The fill image must be dark.** `assets/hero-type-fabric.png` is a pre-processed crop of a draped-silk still-life: greyscaled, gamma-crushed (`pow(x, 2.35) * 0.66`), warmed ~10/0/−6 RGB toward chocolate, mean luma ≈ 70. A normal-exposure photo makes the letters fill with pale grey and the headline disappears against the cream ground. If you swap the image, re-darken it to roughly the same mean luma **and** keep the `linear-gradient` wash layer.
- **Don't use a face.** An earlier version filled the type with the founder's portrait; a giant drifting eye is unsettling. Abstract texture (fabric folds, dappled light, paper) only.
- `fillDrift` animates **both** background layers, so every keyframe must list two comma-separated values for `background-position` and `background-size` or the wash layer snaps.
- CSS animations outrank inline/base declarations, so the animated `background-position`/`-size` take over from the static values once `fillDrift` starts — the static values are what paints during the 1.3s delay, so keep them equal to the `0%` keyframe.
- Keep `background-clip: text` on the `<h1>` itself. Wrapping it in a clipping ancestor or applying `filter`/`backdrop-filter` to a parent breaks the clip in Safari.

## The parallax slab

The `<h1>` and the scan line share a wrapper (`.hero__slab`). **All** JS writes go to that wrapper's `transform` and `opacity` — never to the headline (which owns the CSS animations) and never through framework state:

```js
damp  = max(0, 1 - scrollY / 620)          // parallax dies off as the hero leaves
x     = mouseX * 10 * damp                 // mouseX/Y normalized to -1…1
y     = mouseY * 6 * damp - scrollY * 0.08 // slab also lifts with scroll
scale = 1 + mouseX * 0.004 * damp
opacity = max(0.15, 1 - scrollY / 900)
```

Both listeners are `{ passive: true }` and coalesced through a single `requestAnimationFrame` (one pending frame max), so pointer movement costs one style write per frame and zero re-renders.

**Framework port:** put the wrapper behind a ref, attach the listeners in your mount effect, and remove them plus `cancelAnimationFrame` on cleanup. Do **not** drive x/y/scale through component state — it re-renders the largest element on the page every mouse move.

## Reduced motion

```css
@media (prefers-reduced-motion: reduce) {
  .hero__type, .hero__meta { animation: none !important; opacity: 1 !important; clip-path: none !important; }
  .hero__scan { display: none !important; }
}
```

The JS also bails early on `matchMedia('(prefers-reduced-motion: reduce)').matches`, so no listeners are attached at all. Result: a static, fully-legible photo-in-type headline.

## Tokens used

| Value | Where |
| --- | --- |
| `#FAF5EA` cream | hero ground |
| `#121110` ink | text stroke, wash layer, CTA fill |
| `#B4322A` red | scan line, meta accent, CTA hover |
| `#33291F` | intro paragraph |
| `#6B5F52` | 10px tracked-caps labels on this cream ground (the dark-ground token `#C9BCAE` fails contrast here — 1.7:1) |
| Archivo Black | headline `clamp(58px, 15.6vw, 250px)`, `line-height .76`, `letter-spacing -.045em`, uppercase |
| Archivo 500/600 | meta + labels, 10px, `.22–.26em` tracking |

## Files

- `hero.html` — runnable reference (open directly; serve the folder if your browser blocks local image loads)
- `assets/hero-type-fabric.png` — the pre-darkened fill (1500×1623)

## Known gaps

- **Responsive is not designed.** `hero.html` ships one starter breakpoint at 720px (single-column lower row, wrapping meta). Verify the headline still reads at three lines on small screens — consider two lines and a smaller `clamp()` floor.
- `-webkit-text-stroke` is non-standard but universally supported; it's only a safety net. If `background-clip: text` is unsupported, the stroke alone keeps the words visible.
- The grain layer is an inline SVG filter for reference convenience — swap it for a tiling texture in production.
